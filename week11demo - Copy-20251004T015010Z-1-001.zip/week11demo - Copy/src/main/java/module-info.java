module com.example.week11demo {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.week11demo to javafx.fxml;
    exports com.example.week11demo;
}