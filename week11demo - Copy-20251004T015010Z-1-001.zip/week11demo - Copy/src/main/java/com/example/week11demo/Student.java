package com.example.week11demo;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Student {
    private final StringProperty fName;
    private final StringProperty lName;
    private final StringProperty idNumber;

    public Student(String fName, String lName, String idNumber) {
        this.fName = new SimpleStringProperty(fName);
        this.lName = new SimpleStringProperty(lName);
        this.idNumber = new SimpleStringProperty(idNumber);
    }

    public StringProperty fNameProperty() {
        return this.fName;
    }

    public StringProperty lNameProperty() {
        return this.lName;
    }

    public StringProperty idNumberProperty() {
        return this.idNumber;
    }
}
