package com.example.week11demo;

import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.List;

public class Logbook {
    private List<AttendanceLog> attendances;
    private ObservableList<Student> students = new SimpleListProperty<>(FXCollections.observableArrayList());

    public void addStudent(Student student) {
       this.students.add(student);
    }

    public ObservableList<Student> studentsListProperty() {
        return this.students;
    }
}
