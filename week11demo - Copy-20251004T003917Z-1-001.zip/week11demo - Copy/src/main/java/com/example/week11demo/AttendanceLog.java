package com.example.week11demo;

import java.io.IOException;
import java.time.LocalDateTime;

public class AttendanceLog {
    private final Student student;
    private LocalDateTime arrivalTime;
    private LocalDateTime departureTime;

    public AttendanceLog(Student student) {
        this.student = student;
    }

    public AttendanceLog(Student student, LocalDateTime arrivalTime, LocalDateTime departureTime) {
        this.student = student;
        this.arrivalTime = arrivalTime;
        this.departureTime = departureTime;
    }

    public LocalDateTime arrive() throws IOException {
        if (this.arrivalTime != null) throw new IOException("Arrival was already set.");
        this.arrivalTime = LocalDateTime.now();
        return this.arrivalTime;
    }

    public LocalDateTime depart() throws IOException {
        if (this.departureTime != null) throw new IOException("Departure was already set.");
        this.departureTime = LocalDateTime.now();
        return this.departureTime;
    }
}
