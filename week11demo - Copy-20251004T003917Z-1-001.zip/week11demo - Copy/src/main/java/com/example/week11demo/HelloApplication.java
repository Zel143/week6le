package com.example.week11demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

public class HelloApplication extends Application {
    Logbook logbook = new Logbook();

    public Optional<Student> showAddStudentDialog() {
        Dialog<Student> studentDialog = new Dialog<>();

        VBox fNameContainer = new VBox();
        Label fNameLabel = new Label("First Name");
        TextField fName = new TextField();
        fNameContainer.getChildren().addAll(fNameLabel, fName);

        VBox lNameContainer = new VBox();
        Label lNameLabel = new Label("Last Name");
        TextField lName = new TextField();
        lNameContainer.getChildren().addAll(lNameLabel, lName);

        VBox idContainer = new VBox();
        Label idLabel = new Label("Student ID Number");
        TextField id = new TextField();
        idContainer.getChildren().addAll(idLabel, id);

        HBox nameContainer = new HBox(fNameContainer, lNameContainer);
        VBox formContainer = new VBox(nameContainer, idContainer);

        studentDialog.getDialogPane().setContent(formContainer);

        ButtonType okBtn = new ButtonType("Confirm", ButtonType.OK.getButtonData());
        ButtonType cancelBtn = new ButtonType("Cancel", ButtonType.CANCEL.getButtonData());

        studentDialog.getDialogPane().getButtonTypes().addAll(okBtn, cancelBtn);

        studentDialog.setResultConverter(buttonType -> {
            if (buttonType.getButtonData() == ButtonType.OK.getButtonData()) {
                return new Student(fName.getText(), lName.getText(), id.getText());
            }
            return null;
        });

        return studentDialog.showAndWait();
    }

    @Override
    public void start(Stage stage) throws IOException {
        TableView<Student> table = new TableView<>();
        TableColumn<Student, String> fNameCol = new TableColumn<>("First Name");
        fNameCol.setCellValueFactory(new PropertyValueFactory<>("fName"));
        TableColumn<Student, String> lNameCol = new TableColumn<>("Last Name");
        lNameCol.setCellValueFactory(new PropertyValueFactory<>("lName"));
        TableColumn<Student, String> idCol = new TableColumn<>("ID Number");
        idCol.setCellValueFactory(new PropertyValueFactory<>("idNumber"));

        table.getColumns().addAll(fNameCol, lNameCol, idCol);

        table.setItems(logbook.studentsListProperty());

        Button showDialog = new Button("Add Student");

        HBox parent = new HBox(table, showDialog);

        showDialog.setOnMouseClicked(e -> {
            Optional<Student> newStudent = showAddStudentDialog();
            System.out.println(newStudent);
            if (newStudent.isPresent()) logbook.addStudent(newStudent.get());
        });

        Scene scene = new Scene(parent, 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }
}
